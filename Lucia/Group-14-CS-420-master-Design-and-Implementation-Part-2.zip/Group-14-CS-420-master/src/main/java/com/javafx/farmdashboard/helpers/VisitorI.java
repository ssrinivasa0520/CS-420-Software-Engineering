package com.javafx.farmdashboard.helpers;

import com.javafx.farmdashboard.model.ItemI;

public interface VisitorI {
    double visit(ItemI item);
}
