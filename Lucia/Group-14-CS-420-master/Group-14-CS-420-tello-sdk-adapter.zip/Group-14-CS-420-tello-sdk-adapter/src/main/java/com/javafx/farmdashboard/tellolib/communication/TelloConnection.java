package com.javafx.farmdashboard.tellolib.communication;

public enum TelloConnection {
  CONNECTED,
  DISCONNECTED
}
