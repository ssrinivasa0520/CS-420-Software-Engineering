package com.javafx.farmdashboard.components;

import com.javafx.farmdashboard.helpers.ItemCreator;
import com.javafx.farmdashboard.model.Item;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;

public class ItemViewComponent {

    TreeView<Item> itemView;

    public ItemViewComponent(TreeView<Item> treeView) {
        this.itemView = treeView;

        initialize();
    }

    public void initialize() {
        Item farm = ItemCreator.createFarm();

        TreeItem<Item> rootItem = new TreeItem<>(farm);
        rootItem.setExpanded(true);
        itemView.setRoot(rootItem);
        itemView.getSelectionModel().select(rootItem);
    }

    public TreeItem<Item> getRootTreeItem() {
        return itemView.getRoot();
    }

    public Item getRootItem() {
        return getRootTreeItem().getValue();
    }

    public TreeItem<Item> getSelectedTreeItem() { return itemView.getSelectionModel().getSelectedItem(); }

    public Item getSelectedItem() { return getSelectedTreeItem().getValue(); }

    public void refresh() {
        itemView.refresh();
    }

    public void setDisable(boolean disabled) {
        itemView.setDisable(disabled);
    }

}
