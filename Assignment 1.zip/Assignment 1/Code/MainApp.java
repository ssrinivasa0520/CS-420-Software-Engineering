package assignment1;

import java.io.IOException;

import assignment1.view.UserInterfaceController;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainApp extends Application {

	private Stage primaryStage;
	private AnchorPane rootLayout;
	
	private ObservableList<String> choiceBoxOptions = FXCollections.observableArrayList();

	@Override
	public void start(Stage primaryStage) {
		
		this.choiceBoxOptions.add("Option 1");
		this.choiceBoxOptions.add("Option 2");
		
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("Assignment 1");

		initRootLayout();

	}

	public void initRootLayout() {
		try {
			// Load root layout from fxml file.
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MainApp.class.getResource("view/UserInterface.fxml"));
			rootLayout = (AnchorPane) loader.load();
			
			UserInterfaceController controller = loader.getController();
	        controller.setMainApp(this);

			// Show the scene containing the root layout.
			Scene scene = new Scene(rootLayout);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Stage getPrimaryStage() {
		return primaryStage;
	}
	
	public ObservableList<String> getChoiceBoxOptions() {
		return this.choiceBoxOptions;
	}

	public static void main(String[] args) {
		launch(args);
	}

}
