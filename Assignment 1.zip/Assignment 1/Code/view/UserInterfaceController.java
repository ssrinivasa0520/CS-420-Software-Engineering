package assignment1.view;

import java.util.Objects;

import assignment1.MainApp;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class UserInterfaceController {
	
	@FXML
	private ChoiceBox<String> choiceBox;
	
	@FXML 
	private TextArea textArea;
	
    private MainApp mainApp;
    
    public UserInterfaceController (){
    }

    
    @FXML
    public void initialize() {
        
    }
    
    @FXML
    public void handleSelectButtonClicked() {
    	String selectedValue = choiceBox.getValue();
    	if(Objects.nonNull(selectedValue)) {
        	this.textArea.appendText(selectedValue + " selected\n");
    	}
    }
    
    @FXML
    public void handleDeleteButtonClicked() {
    	String selectedValue = choiceBox.getValue();
    	if(Objects.nonNull(selectedValue)) {
    		this.textArea.appendText(selectedValue + " deleted\n");
    	}
    }
    
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;

        choiceBox.setItems(mainApp.getChoiceBoxOptions());
    }

}
