package items;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.SocketException;
import java.net.UnknownHostException;


public class SimulationAdapter implements AdapterInterface{
    

    public void visitItem(ItemInfo selection) throws IOException, InterruptedException {

    }
    public void scanFarm(ItemInfo selection) throws IOException, InterruptedException {

    }
}
